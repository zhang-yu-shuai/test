<template>
  <div>1212</div>
</template>

<script>
export default {
  name: "UserInfo"
}
</script>

<style scoped>

</style>