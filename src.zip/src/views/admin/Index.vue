<template>


</template>

<script>
import Layout from "@/views/admin/layout/Index.vue";

export default {
  name: "Admin",
  components:{
    Layout
  }
}
</script>

<style lang="scss" scoped>

</style>