<template>
<div class="headerc">
   <div class="word">
     欢迎来到电子拍卖系统拍卖端
   </div>
</div>
</template>

<script>
export default {
  name: "businessHeader"
}
</script>

<style lang="scss" scoped>
.headerc{
  display: flex;
  height: 60px;
  background:#DCDFE6;
  .word{
    margin: auto;
    font-size: 25px;
    color: black;
  }
}
</style>