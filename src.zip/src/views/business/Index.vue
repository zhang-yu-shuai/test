<template>


</template>

<script>
import Layout from "@/views/business/layout/Index.vue";

export default {
  name: "Business",
  components:{
    Layout
  }
}
</script>

<style lang="scss" scoped>

</style>